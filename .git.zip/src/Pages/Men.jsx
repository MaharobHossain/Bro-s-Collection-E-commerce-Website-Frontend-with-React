import React from 'react'

const Men = () => {
  return (
    <div>
      this is men page.
    </div>
  )
}

export default Men;
