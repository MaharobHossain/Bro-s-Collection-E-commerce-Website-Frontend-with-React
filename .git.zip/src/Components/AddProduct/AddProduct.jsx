import React from 'react'

const AddProduct = () => {
  return (
    <div className='add-product'>
      
    </div>
  )
}

export default AddProduct;
